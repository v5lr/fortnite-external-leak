#pragma once

#include <iostream>
#include <string>

class core_t
{
public:
	void start();
}; inline core_t core;