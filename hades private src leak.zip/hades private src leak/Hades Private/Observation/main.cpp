﻿#include "core/core.h"

int main()
{
	core.start();
}